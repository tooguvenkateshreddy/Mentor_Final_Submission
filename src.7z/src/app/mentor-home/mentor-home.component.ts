import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mentor-home',
  templateUrl: './mentor-home.component.html',
  styleUrls: ['./mentor-home.component.css']
})
export class MentorHomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
