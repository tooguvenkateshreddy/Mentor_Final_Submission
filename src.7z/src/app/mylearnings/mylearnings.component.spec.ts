import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MylearningsComponent } from './mylearnings.component';

describe('MylearningsComponent', () => {
  let component: MylearningsComponent;
  let fixture: ComponentFixture<MylearningsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MylearningsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MylearningsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
